﻿using System;
using System.Text;
using System.Numerics;

namespace ConsoleApplication1
{
    class Program
    {
        static public BigInteger factorial(int fact)
        {
            BigInteger result = 1;
            for (int i = fact; i >= 1; i--) result *= (BigInteger)i;
            return result;
        }

        static public int factorial_digits_sum(BigInteger fact_res)
        {
            char[] array = fact_res.ToString().ToCharArray();
            int result = 0;
            for (int i = 0; i < array.Length; i++) result += Convert.ToInt16(array[i].ToString());
            return result;
        }

        static void Main(string[] args)
        {
            Console.Write("Enter the number to process factorial calculation: ");
            int input = (int)Convert.ToInt64(Console.ReadLine());
            Console.WriteLine(input.ToString() + " factorial = " + factorial(input).ToString());
            Console.WriteLine(input.ToString() + " factorial_digits_sum = " + factorial_digits_sum(factorial(input)).ToString());
        }
    }
}